---
layout: page
title: Full Specification
---

{% include_relative semantic_docstrings_body.md %}
