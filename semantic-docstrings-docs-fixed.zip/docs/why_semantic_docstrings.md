---
layout: page
title: Why Semantic Docstrings
---

{% include_relative why_semantic_docstrings_body.md %}
